import json
import requests

def handler(event, context):
    response = requests.get("https://randomuser.me/api/")
    data = json.loads(response.text)
    print(data)
    